package ir.alizadeh.accountant;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** JARVIS remote AI client. API key is user-provided and kept locally. */
public class AIClient {
    public interface Callback { void done(String text, String error); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final String endpoint, apiKey, model;
    public AIClient(String endpoint, String apiKey, String model){
        this.endpoint = endpoint == null || endpoint.trim().isEmpty() ? "https://api.openai.com/v1/responses" : endpoint.trim();
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.model = model == null || model.trim().isEmpty() ? "gpt-5.6" : model.trim();
    }
    public void ask(final String system, final String user, final Callback cb){
        new Thread(() -> {
            String out=null, err=null;
            try {
                if(apiKey.isEmpty()) throw new IllegalStateException("کلید API وارد نشده است.");
                JSONObject body=new JSONObject();
                body.put("model",model);
                body.put("input", system+"\n\nپیام کاربر:\n"+user);
                HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(90000); c.setDoOutput(true);
                c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+apiKey);
                try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();
                String json=read(is);
                if(code<200||code>=300) throw new IOException("HTTP "+code+": "+json);
                JSONObject r=new JSONObject(json); out=extractText(r);
                if(out==null||out.trim().isEmpty()) throw new IOException("پاسخ متنی از JARVIS دریافت نشد.");
            } catch(Exception e){err=e.getMessage();}
            final String fo=out, fe=err; main.post(() -> cb.done(fo,fe));
        }).start();
    }
    private String read(InputStream is) throws Exception { if(is==null)return ""; StringBuilder s=new StringBuilder(); byte[] b=new byte[8192]; int n; while((n=is.read(b))!=-1)s.append(new String(b,0,n,StandardCharsets.UTF_8)); return s.toString(); }
    private String extractText(JSONObject r) throws Exception {
        if(r.has("output_text")) return r.optString("output_text","");
        JSONArray out=r.optJSONArray("output"); if(out==null)return ""; StringBuilder s=new StringBuilder();
        for(int i=0;i<out.length();i++){ JSONObject item=out.optJSONObject(i); if(item==null)continue; JSONArray content=item.optJSONArray("content"); if(content==null)continue;
            for(int j=0;j<content.length();j++){ JSONObject x=content.optJSONObject(j); if(x==null)continue; String t=x.optString("text",""); if(!t.isEmpty()){if(s.length()>0)s.append('\n');s.append(t);} }
        } return s.toString();
    }
}
