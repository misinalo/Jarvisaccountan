package ir.alizadeh.accountant;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Color;
import android.os.*;
import android.print.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    static final int BLUE=Color.rgb(21,101,192), DARK=Color.rgb(25,25,25), BG=Color.rgb(247,249,252), GREEN=Color.rgb(30,125,70), RED=Color.rgb(190,50,50);
    DB db; LinearLayout body; TextView title, summary; String lastInvoice="";
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44); showHome();}
    TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(DARK);t.setPadding(16,12,16,12);t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setAllCaps(false);b.setPadding(10,4,10,4);b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return b;}
    EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(15);e.setPadding(12,7,12,7);e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return e;}
    void base(String t){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView h=tv(t,21);h.setGravity(Gravity.CENTER);h.setTextColor(Color.WHITE);h.setBackgroundColor(BLUE);root.addView(h,new LinearLayout.LayoutParams(-1,58));body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(10,8,10,10);ScrollView sc=new ScrollView(this);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void addBtn(String s,View.OnClickListener l){Button b=btn(s);b.setOnClickListener(l);body.addView(b,new LinearLayout.LayoutParams(-1,56));}
    void card(String s){TextView t=tv(s,16);t.setBackgroundColor(Color.WHITE);body.addView(t,new LinearLayout.LayoutParams(-1,-2));}
    String money(long x){return String.format(Locale.US,"%,d",x);} long num(EditText e){try{return Long.parseLong(e.getText().toString().replace(",",""));}catch(Exception x){return 0;}} double qty(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception x){return 0;}}
    String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());} String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    void showHome(){base("JARVIS | حسابدار علیزاده");summary=tv("",16);summary.setBackgroundColor(Color.WHITE);body.addView(summary);refresh();
        addBtn("➕ فروش سریع",v->saleDialog(false)); addBtn("🧾 پیش‌فاکتور",v->saleDialog(true)); addBtn("📦 خرید / ورود کالا",v->purchaseDialog());
        addBtn("🏷 کالا و قیمت‌گذاری",v->products()); addBtn("👤 مشتریان / بدهکاران",v->customers()); addBtn("📑 فاکتورها و مرجوعی",v->invoices());
        addBtn("🏦 صندوق / کارتخوان / بانک / چک",v->cashbook()); addBtn("💸 هزینه و اقساط",v->expenses()); addBtn("⏰ یادآوری‌ها",v->reminders());
        addBtn("📊 گزارش سود، کاردکس و انبار",v->reports()); addBtn("💰 صندوق خرید و تقسیم پول",v->fund()); addBtn("🤖 JARVIS | دستیار هوشمند",v->assistant()); addBtn("⚙ تنظیمات و پشتیبان",v->settings());
        TextView nav=tv("پیشخوان     فروش سریع     انبار     حساب‌ها",14);nav.setGravity(Gravity.CENTER);nav.setTextColor(BLUE);body.addView(nav); }
    void refresh(){long sales=db.sum("sales","total","kind='SALE'");long profit=db.sum("sales","profit","kind='SALE'");long inv=db.inventoryValue();long fund=db.sum("alloc","amount","bucket='خرید'");long target=db.get("fund",50000000);long receivable=db.sum("customers","balance",null);long low=db.lowStockCount();summary.setText("فروش: "+money(sales)+" تومان   |   سود ناخالص: "+money(profit)+" تومان\nارزش موجودی: "+money(inv)+" تومان   |   صندوق خرید: "+money(fund)+" / "+money(target)+"\nمطالبات مشتریان: "+money(receivable)+" تومان   |   هشدار موجودی کم: "+low+" کالا");}
    void saleDialog(boolean pro){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input("نام کالا"),q=input("تعداد"),pr=input("قیمت فروش (خالی = قیمت کالا)"),dis=input("تخفیف"),cust=input("مشتری"),paid=input("دریافتی"),priceType=input("نوع قیمت: 1 عادی / 2 عمده / 3 ویژه");q.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);for(EditText e:new EditText[]{n,q,pr,dis,cust,paid,priceType})l.addView(e);new AlertDialog.Builder(this).setTitle(pro?"پیش‌فاکتور":"فروش جدید").setView(l).setPositiveButton("ثبت",(d,w)->postSale(n.getText().toString(),qty(q),num(pr),num(dis),cust.getText().toString(),num(paid),priceType.getText().toString(),pro)).setNegativeButton("لغو",null).show();}
    void postSale(String name,double q,long manual,long discount,String customer,long paid,String pt,boolean pro){if(q<=0){toast("تعداد نامعتبر است");return;}Product p=db.find(name);if(p==null){toast("کالا پیدا نشد");return;}long price=manual>0?manual:("2".equals(pt)?p.sale2:("3".equals(pt)?p.sale3:p.sale1));long total=Math.max(0,Math.round(q*price)-discount);long profit=Math.max(0,Math.round(q*(price-p.cost))-discount);if(!pro&&p.stock+0.000001<q){toast("موجودی کافی نیست: "+p.stock);return;}if(paid>total)paid=total;long id=db.postSale(p.id,p.name,q,price,discount,total,profit,customer,paid,pro?"PROFORMA":"SALE");if(!pro)lastInvoice=invoiceText(id);else lastInvoice=invoiceText(id);toast(pro?"پیش‌فاکتور ثبت شد":"فروش ثبت شد");refresh();}
    String invoiceText(long id){Cursor c=db.q("SELECT id,dt,kind,product,qty,price,discount,total,profit,customer,paid FROM sales WHERE id="+id);if(!c.moveToFirst()){c.close();return "";}String s="فروشگاه علیزاده\nفاکتور #"+c.getLong(0)+"\nتاریخ: "+c.getString(1)+"\nنوع: "+(c.getString(2).equals("SALE")?"فروش":"پیش‌فاکتور")+"\nکالا: "+c.getString(3)+"\nتعداد: "+c.getDouble(4)+"\nفی: "+money(c.getLong(5))+"\nتخفیف: "+money(c.getLong(6))+"\nجمع: "+money(c.getLong(7))+" تومان\nدریافت: "+money(c.getLong(10))+" تومان\nمانده: "+money(Math.max(0,c.getLong(7)-c.getLong(10)))+" تومان\nمشتری: "+c.getString(9);c.close();return s;}
    void purchaseDialog(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input("کالا"),q=input("تعداد"),c=input("قیمت خرید هر عدد"),sup=input("تامین‌کننده"),paid=input("پرداخت به تامین‌کننده");for(EditText e:new EditText[]{n,q,c,sup,paid})l.addView(e);new AlertDialog.Builder(this).setTitle("ثبت خرید").setView(l).setPositiveButton("ثبت",(d,w)->{Product p=db.find(n.getText().toString());double qq=qty(q);long cc=num(c);if(qq<=0||cc<=0){toast("تعداد/قیمت نامعتبر");return;}if(p==null){db.create(n.getText().toString(),cc,cc,cc,cc,0);p=db.find(n.getText().toString());}db.postPurchase(p.id,p.name,qq,cc,sup.getText().toString(),num(paid));toast("خرید ثبت شد و کاردکس به‌روزرسانی شد");refresh();}).setNegativeButton("لغو",null).show();}
    void products(){base("کالاها و قیمت‌گذاری");addBtn("➕ کالای جدید",v->addProduct());Cursor c=db.q("SELECT id,name,stock,cost,sale1,sale2,sale3,minStock FROM products ORDER BY id DESC");while(c.moveToNext()){int id=c.getInt(0);Button b=btn(c.getString(1)+" | موجودی "+c.getDouble(2)+" | خرید "+money(c.getLong(3))+" | قیمت ۱ "+money(c.getLong(4))+" | حداقل "+c.getDouble(7));b.setOnClickListener(v->editProduct(id));body.addView(b);}c.close();addBtn("↩ بازگشت",v->showHome());}
    void addProduct(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input("نام کالا"),c=input("قیمت خرید"),m=input("درصد سود روی خرید"),s2=input("قیمت عمده (اختیاری)"),s3=input("قیمت ویژه (اختیاری)"),min=input("حداقل موجودی برای هشدار");for(EditText e:new EditText[]{n,c,m,s2,s3,min})l.addView(e);new AlertDialog.Builder(this).setTitle("کالای جدید").setView(l).setPositiveButton("ذخیره",(d,w)->{long co=num(c);double ma=0;try{ma=Double.parseDouble(m.getText().toString());}catch(Exception ignored){}long s=Math.round(co*(1+ma/100));long a=num(s2),b=num(s3);db.create(n.getText().toString(),co,s,a>0?a:s,b>0?b:s,qty(min));products();}).setNegativeButton("لغو",null).show();}
    void editProduct(int id){Product p=db.getProduct(id);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input("نام");n.setText(p.name);EditText c=input("قیمت خرید");c.setText(""+p.cost);EditText s=input("قیمت عادی");s.setText(""+p.sale1);EditText s2=input("قیمت عمده");s2.setText(""+p.sale2);EditText s3=input("قیمت ویژه");s3.setText(""+p.sale3);EditText min=input("حداقل موجودی");min.setText(""+p.minStock);for(EditText e:new EditText[]{n,c,s,s2,s3,min})l.addView(e);new AlertDialog.Builder(this).setTitle("ویرایش کالا").setView(l).setPositiveButton("ذخیره",(d,w)->{db.updateProduct(id,n.getText().toString(),num(c),num(s),num(s2),num(s3),qty(min));products();}).setNegativeButton("لغو",null).show();}
    void customers(){base("مشتریان و بدهکاران");addBtn("➕ ثبت دریافت از مشتری",v->paymentDialog(false));Cursor c=db.q("SELECT id,name,balance FROM customers ORDER BY balance DESC");while(c.moveToNext()){body.addView(tv(c.getString(1)+" — مانده: "+money(c.getLong(2))+" تومان",16));}c.close();addBtn("↩ بازگشت",v->showHome());}
    void paymentDialog(boolean supplier){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input(supplier?"تامین‌کننده":"مشتری"),a=input("مبلغ دریافت/پرداخت");l.addView(n);l.addView(a);new AlertDialog.Builder(this).setTitle(supplier?"پرداخت به تامین‌کننده":"دریافت از مشتری").setView(l).setPositiveButton("ثبت",(d,w)->{long x=num(a);if(x<=0)return;db.payment(n.getText().toString(),supplier?-x:x,supplier?"supplier":"customer");toast("ثبت شد");}).setNegativeButton("لغو",null).show();}
    void invoices(){base("فاکتورها");addBtn("↩ مرجوعی فروش",v->returnDialog());Cursor c=db.q("SELECT id,dt,kind,product,qty,total,customer,paid FROM sales ORDER BY id DESC");while(c.moveToNext()){long id=c.getLong(0);Button b=btn("#"+id+" | "+(c.getString(2).equals("SALE")?"فروش":"پیش‌فاکتور")+" | "+c.getString(3)+" × "+c.getDouble(4)+" | "+money(c.getLong(5))+" تومان");b.setOnClickListener(v->{lastInvoice=invoiceText(id);share(lastInvoice);});body.addView(b);}c.close();addBtn("↩ بازگشت",v->showHome());}
    void returnDialog(){EditText id=input("شماره فاکتور فروش"),q=input("تعداد مرجوعی");LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.addView(id);l.addView(q);new AlertDialog.Builder(this).setTitle("ثبت مرجوعی").setView(l).setPositiveButton("ثبت",(d,w)->{db.returnSale(Long.parseLong(id.getText().toString()),qty(q));toast("مرجوعی ثبت و موجودی اصلاح شد");refresh();}).setNegativeButton("لغو",null).show();}
    void cashbook(){base("دریافت، پرداخت و چک");addBtn("➕ ثبت دریافت",v->cashDialog(true));addBtn("➖ ثبت پرداخت",v->cashDialog(false));addBtn("🧾 ثبت چک",v->checkDialog());Cursor c=db.q("SELECT dt,title,amount,kind,status FROM cashbook ORDER BY id DESC LIMIT 30");while(c.moveToNext())body.addView(tv(c.getString(1)+" | "+(c.getString(3).equals("IN")?"دریافت":"پرداخت")+" | "+money(c.getLong(2))+" | "+c.getString(4),15));c.close();addBtn("↩ بازگشت",v->showHome());}
    void cashDialog(boolean in){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText t=input("عنوان"),a=input("مبلغ"),note=input("توضیح");l.addView(t);l.addView(a);l.addView(note);new AlertDialog.Builder(this).setTitle(in?"ثبت دریافت":"ثبت پرداخت").setView(l).setPositiveButton("ثبت",(d,w)->db.cash(t.getText().toString(),num(a),in?"IN":"OUT","نقدی",note.getText().toString())).setNegativeButton("لغو",null).show();}
    void checkDialog(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText t=input("نام طرف حساب"),a=input("مبلغ چک"),due=input("سررسید: 1405/07/15"),no=input("شماره چک"),kind=input("نوع: 1 دریافتی / 2 پرداختی");for(EditText e:new EditText[]{t,a,due,no,kind})l.addView(e);new AlertDialog.Builder(this).setTitle("ثبت چک").setView(l).setPositiveButton("ثبت",(d,w)->db.check(t.getText().toString(),num(a),due.getText().toString(),no.getText().toString(),"2".equals(kind.getText().toString().trim())?"پرداختی":"دریافتی")).setNegativeButton("لغو",null).show();}
    void expenses(){base("هزینه و اقساط");addBtn("➕ هزینه",v->expense(false));addBtn("➕ قسط",v->expense(true));Cursor c=db.q("SELECT dt,title,amount,type,paid FROM expenses ORDER BY id DESC");while(c.moveToNext())body.addView(tv(c.getString(1)+" | "+c.getString(3)+" | "+money(c.getLong(2))+" | "+(c.getInt(4)==1?"پرداخت شده":"باز"),15));c.close();addBtn("↩ بازگشت",v->showHome());}
    void expense(boolean inst){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText t=input(inst?"عنوان قسط":"عنوان هزینه"),a=input("مبلغ"),due=input("سررسید اختیاری: 1405/07/15");l.addView(t);l.addView(a);l.addView(due);new AlertDialog.Builder(this).setTitle(inst?"ثبت قسط":"ثبت هزینه").setView(l).setPositiveButton("ثبت",(d,w)->{long id=db.expense(t.getText().toString(),num(a),inst?"قسط":"هزینه",due.getText().toString(),!inst);if(inst&&!due.getText().toString().trim().isEmpty())scheduleReminder(id,t.getText().toString(),"سررسید قسط: "+t.getText().toString(),due.getText().toString());}).setNegativeButton("لغو",null).show();}
    void reminders(){base("یادآوری‌ها");addBtn("➕ یادآوری جدید",v->addReminder());Cursor c=db.q("SELECT id,title,note,due,done FROM reminders ORDER BY done,due");while(c.moveToNext()){long id=c.getLong(0);Button b=btn((c.getInt(4)==1?"✅ ":"⏰ ")+c.getString(1)+" | "+c.getString(3));b.setOnClickListener(v->markReminder(id));body.addView(b);}c.close();addBtn("↩ بازگشت",v->showHome());}
    void addReminder(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText t=input("عنوان یادآوری"),n=input("توضیح"),d=input("تاریخ/ساعت: 1405-07-15 10:00");l.addView(t);l.addView(n);l.addView(d);new AlertDialog.Builder(this).setTitle("یادآوری جدید").setView(l).setPositiveButton("ذخیره",(x,w)->{long id=db.reminder(t.getText().toString(),n.getText().toString(),d.getText().toString());scheduleReminder(id,t.getText().toString(),n.getText().toString(),d.getText().toString());reminders();}).setNegativeButton("لغو",null).show();}
    void markReminder(long id){db.doneReminder(id);toast("یادآوری انجام شد");reminders();}
    Date parseUserDate(String date) throws Exception {
        String x=date.trim().replace('/', '-');
        String[] parts=x.split(" ");
        String ds=parts[0]; String tm=parts.length>1?parts[1]:"09:00";
        String[] ymd=ds.split("-");
        int y=Integer.parseInt(ymd[0]), m=Integer.parseInt(ymd[1]), day=Integer.parseInt(ymd[2]);
        if(y>=1300 && y<=1600){ int[] g=jalaliToGregorian(y,m,day); y=g[0];m=g[1];day=g[2]; }
        return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(String.format(Locale.US,"%04d-%02d-%02d %s",y,m,day,tm));
    }
    int[] jalaliToGregorian(int jy,int jm,int jd){
        int[] breaks={-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178};
        int gy=jy+621, leapJ=-14, jp=breaks[0], jump=0;
        for(int i=1;i<breaks.length;i++){int jmbr=breaks[i]; jump=jmbr-jp; if(jy<jmbr) break; leapJ+=jump/33*8 + jump%33/4; jp=jmbr;}
        int n=jy-jp; leapJ+=n/33*8 + (n%33+3)/4; if(jump%33==4 && jump-n==4) leapJ++;
        int leapG=gy/4 - ((gy/100+1)*3)/4 - 150;
        int march=20 + leapJ - leapG;
        if(jm<=6) n=(jm-1)*31+(jd-1); else n=(jm-7)*30+(jd-1)+186;
        int gDay=n+march; int gMonth=3;
        if(gDay>31){gDay-=31;gMonth=4;}
        if(gDay>30 && gMonth==4){gDay-=30;gMonth=5;}
        if(gDay>31 && gMonth==5){gDay-=31;gMonth=6;}
        if(gDay>30 && gMonth==6){gDay-=30;gMonth=7;}
        if(gDay>31 && gMonth==7){gDay-=31;gMonth=8;}
        if(gDay>31 && gMonth==8){gDay-=31;gMonth=9;}
        if(gDay>30 && gMonth==9){gDay-=30;gMonth=10;}
        if(gDay>31 && gMonth==10){gDay-=31;gMonth=11;}
        if(gDay>30 && gMonth==11){gDay-=30;gMonth=12;}
        if(gDay>31 && gMonth==12){gDay-=31;gMonth=1;gy++;}
        return new int[]{gy,gMonth,gDay};
    }
    void scheduleReminder(long id,String title,String text,String date){try{Date d=parseUserDate(date);if(d==null)return;Intent in=new Intent(this,ReminderReceiver.class);in.putExtra("title",title);in.putExtra("text",text);PendingIntent pi=PendingIntent.getBroadcast(this,(int)id,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,d.getTime(),pi);}catch(Exception e){toast("قالب تاریخ صحیح نیست");}}
    void reports(){base("گزارش‌ها");addBtn("📈 سود و فروش",v->{card("کل فروش: "+money(db.sum("sales","total","kind='SALE'"))+" تومان\nسود ناخالص: "+money(db.sum("sales","profit","kind='SALE'"))+" تومان\nفروش امروز: "+money(db.todaySales())+" تومان\nسود امروز: "+money(db.todayProfit())+" تومان\nمطالبات: "+money(db.sum("customers","balance",null))+" تومان");});addBtn("📦 کاردکس کالا",v->cardex());addBtn("⚠ کالاهای کم‌موجودی",v->lowStock());addBtn("↩ بازگشت",v->showHome());}
    void cardex(){base("کاردکس");Cursor c=db.q("SELECT dt,product,kind,qty,balance,amount FROM movements ORDER BY id DESC LIMIT 100");while(c.moveToNext())body.addView(tv(c.getString(1)+" | "+c.getString(2)+" | "+c.getDouble(3)+" | مانده "+c.getDouble(4)+" | "+money(c.getLong(5)),14));c.close();addBtn("↩ بازگشت",v->reports());}
    void lowStock(){base("هشدار موجودی");Cursor c=db.q("SELECT name,stock,minStock FROM products WHERE stock<=minStock ORDER BY stock");while(c.moveToNext())body.addView(tv("⚠ "+c.getString(0)+" | موجودی "+c.getDouble(1)+" | حداقل "+c.getDouble(2),16));c.close();addBtn("↩ بازگشت",v->reports());}
    void fund(){base("صندوق خرید و تقسیم پول");long target=db.get("fund",50000000),saved=db.sum("alloc","amount","bucket='خرید'");card("هدف خرید: "+money(target)+" تومان\nذخیره خرید: "+money(saved)+" تومان\nباقی‌مانده: "+money(Math.max(0,target-saved))+" تومان");addBtn("⚙ تنظیم درصد تقسیم",v->allocSettings());addBtn("↩ بازگشت",v->showHome());}
    void allocSettings(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText a=input("درصد خرید");a.setText("50");EditText b=input("درصد قسط/هزینه");b.setText("30");EditText c=input("درصد شخصی");c.setText("20");l.addView(a);l.addView(b);l.addView(c);new AlertDialog.Builder(this).setTitle("تقسیم مبلغ دریافتی").setView(l).setPositiveButton("ذخیره",(d,w)->{double total=Double.parseDouble(a.getText().toString())+Double.parseDouble(b.getText().toString())+Double.parseDouble(c.getText().toString());if(Math.abs(total-100)>0.001){toast("جمع درصدها باید ۱۰۰ باشد");return;}db.set("buy",num(a));db.set("inst",num(b));db.set("personal",num(c));}).setNegativeButton("لغو",null).show();}
    void assistant(){
        base("🤖 دستیار AI علیزاده");
        card("دستیار می‌تواند اطلاعات فروشگاه را بررسی کند، سؤال جواب بدهد و برای عملیات حساس پیشنهاد انجام کار بدهد.\n\nنمونه‌ها:\n«امروز چقدر سود کردم؟»\n«پمپ نیم اسب کم شده؟»\n«قیمت فروش این کالا با ۲۵٪ سود واقعی چقدر است؟»\n«۱ میلیون هزینه برق ثبت کن»\n«برای پرداخت قسط فردا ساعت ۱۰ یادآوری بساز»\n«فروش این ماه را تحلیل کن و بگو کجا پولم بیشتر گیر کرده»");
        EditText q=input("دستورت را بنویس..."); body.addView(q);
        addBtn("🚀 پرسیدن از AI",v->{String x=q.getText().toString().trim(); if(x.isEmpty()){toast("دستور را بنویس");return;} askAI(x);});
        addBtn("⚙ تنظیم AI",v->aiSettings());
        addBtn("↩ بازگشت",v->showHome());
    }
    String aiSystem(){
        StringBuilder b=new StringBuilder();
        b.append("تو دستیار هوشمند حسابداری فروشگاه پمپ آب «فروشگاه علیزاده» هستی. فارسی روان و کوتاه جواب بده. ");
        b.append("داده‌های زیر وضعیت فعلی فروشگاه هستند. هیچ عددی را حدس نزن و اگر داده کافی نیست بگو. ");
        b.append("در محاسبات پولی از تومان و عدد صحیح استفاده کن. سود «حاشیه سود از فروش» با «درصد اضافه روی خرید» را قاطی نکن. ");
        b.append("برای عملیات تغییردهنده اطلاعات، فقط پیشنهاد بده و هرگز ادعا نکن ثبت شد مگر خود برنامه آن را اجرا کرده باشد. ");
        b.append("اگر کاربر سؤال تحلیلی دارد، از داده‌ها تحلیل کن؛ اگر دستور اجرایی دارد، یک JSON تک‌خطی در انتهای پاسخ با این قالب بده: ");
        b.append("ACTION={\"type\":\"none|expense|reminder|price|sell|purchase\",\"amount\":0,\"product\":\"\",\"qty\":0,\"percent\":0,\"title\":\"\",\"due\":\"\"}. ");
        b.append("فقط وقتی همه پارامترهای لازم را داری action پیشنهاد بده. برای sell/purchase/expense قبل از اجرای واقعی باید برنامه از کاربر تأیید بگیرد. ");
        b.append("\nاطلاعات فروشگاه:\n");
        b.append("فروش کل=").append(db.sum("sales","total","kind='SALE'"));
        b.append("، سود کل=").append(db.sum("sales","profit","kind='SALE'"));
        b.append("، فروش امروز=").append(db.todaySales());
        b.append("، سود امروز=").append(db.todayProfit());
        b.append("، ارزش موجودی=").append(db.inventoryValue());
        b.append("، مطالبات مشتریان=").append(db.sum("customers","balance",null));
        b.append("، صندوق خرید=").append(db.sum("alloc","amount","bucket='خرید'"));
        b.append("، هدف صندوق=").append(db.get("fund",50000000));
        b.append("\nکالاها:\n");
        Cursor c=db.q("SELECT name,stock,cost,sale1,sale2,sale3,minStock FROM products ORDER BY name LIMIT 150");
        while(c.moveToNext()) b.append(c.getString(0)).append(" | موجودی=").append(c.getDouble(1)).append(" | خرید=").append(c.getLong(2)).append(" | عادی=").append(c.getLong(3)).append(" | عمده=").append(c.getLong(4)).append(" | ویژه=").append(c.getLong(5)).append(" | حداقل=").append(c.getDouble(6)).append("\n");
        c.close();
        b.append("\nیادآوری‌های باز:\n");
        c=db.q("SELECT title,due,note FROM reminders WHERE done=0 ORDER BY due LIMIT 30");
        while(c.moveToNext()) b.append(c.getString(0)).append(" | ").append(c.getString(1)).append(" | ").append(c.getString(2)).append("\n"); c.close();
        return b.toString();
    }
    void askAI(String q){
        String key=getPreferences(MODE_PRIVATE).getString("ai_key","");
        String model=getPreferences(MODE_PRIVATE).getString("ai_model","gpt-5.6-luna");
        String endpoint=getPreferences(MODE_PRIVATE).getString("ai_endpoint","https://api.openai.com/v1/responses");
        if(key.isEmpty()){toast("اول از تنظیم AI کلید API را وارد کن");return;}
        toast("در حال فکر کردن...");
        new AIClient(endpoint,key,model).ask(aiSystem(),q,(text,error)->{
            if(error!=null){toast("خطای AI: "+error);return;}
            handleAIResponse(text);
        });
    }
    void handleAIResponse(String text){
        String clean=text; String action=null;
        int p=text.indexOf("ACTION=");
        if(p>=0){action=text.substring(p+7).trim(); clean=text.substring(0,p).trim();}
        final String a=action;
        new AlertDialog.Builder(this).setTitle("پاسخ دستیار AI").setMessage(clean).setPositiveButton(a==null?"باشه":"بررسی عملیات",(d,w)->{if(a!=null) executeAIAction(a);}).setNegativeButton("بستن",null).show();
    }
    void executeAIAction(String raw){
        try{
            JSONObject a=new JSONObject(raw);
            String type=a.optString("type","none");
            if("none".equals(type))return;
            if("expense".equals(type)){
                long amount=a.optLong("amount",0); String title=a.optString("title","هزینه توسط AI");
                if(amount<=0){toast("مبلغ عملیات مشخص نیست");return;}
                new AlertDialog.Builder(this).setTitle("تأیید ثبت هزینه").setMessage("عنوان: "+title+"\nمبلغ: "+money(amount)+" تومان\n\nثبت شود؟").setPositiveButton("ثبت",(d,w)->{db.expense(title,amount,"هزینه","",true);toast("هزینه ثبت شد");showHome();}).setNegativeButton("لغو",null).show(); return;
            }
            if("reminder".equals(type)){
                String title=a.optString("title","یادآوری"); String due=a.optString("due","");
                if(due.isEmpty()){toast("تاریخ یادآوری مشخص نیست");return;}
                new AlertDialog.Builder(this).setTitle("تأیید یادآوری").setMessage(title+"\n"+due+"\n\nثبت شود؟").setPositiveButton("ثبت",(d,w)->{long id=db.reminder(title,"ساخته‌شده توسط AI",due);scheduleReminder(id,title,"ساخته‌شده توسط AI",due);toast("یادآوری ثبت شد");}).setNegativeButton("لغو",null).show(); return;
            }
            if("price".equals(type)){
                String product=a.optString("product",""); double percent=a.optDouble("percent",0); Product p=db.find(product);
                if(p==null){toast("کالا پیدا نشد");return;} long price=Math.round(p.cost*(1+percent/100.0));
                new AlertDialog.Builder(this).setTitle("پیشنهاد قیمت").setMessage("کالا: "+p.name+"\nخرید: "+money(p.cost)+"\nدرصد اضافه روی خرید: "+percent+"٪\nقیمت پیشنهادی: "+money(price)+" تومان\n\nقیمت ذخیره شود؟").setPositiveButton("ذخیره",(d,w)->{db.updateProduct(p.id,p.name,p.cost,price,p.sale2,p.sale3,p.minStock);toast("قیمت ذخیره شد");}).setNegativeButton("لغو",null).show(); return;
            }
            if("sell".equals(type)){
                String product=a.optString("product",""); double q=a.optDouble("qty",0); Product p=db.find(product);
                if(p==null||q<=0){toast("کالا یا تعداد مشخص نیست");return;}
                long price=p.sale1; long total=Math.round(q*price);
                new AlertDialog.Builder(this).setTitle("تأیید فروش پیشنهادی").setMessage("کالا: "+p.name+"\nتعداد: "+q+"\nقیمت: "+money(price)+"\nجمع: "+money(total)+" تومان\n\nبرای ثبت نهایی مشخصات فاکتور را بررسی کن.").setPositiveButton("ادامه",(d,w)->saleDialog(false)).setNegativeButton("لغو",null).show(); return;
            }
            if("purchase".equals(type)){toast("برای خرید، ثبت خرید را باز کن تا مقدار و تامین‌کننده نهایی شود.");purchaseDialog();return;}
        }catch(Exception e){toast("عملیات AI قابل اجرا نبود؛ پاسخ را بررسی کن.");}
    }
    void aiSettings(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);
        EditText key=input("کلید API (sk-...)"); key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); key.setText(getPreferences(MODE_PRIVATE).getString("ai_key",""));
        EditText model=input("مدل"); model.setText(getPreferences(MODE_PRIVATE).getString("ai_model","gpt-5.6-luna"));
        EditText endpoint=input("آدرس API"); endpoint.setText(getPreferences(MODE_PRIVATE).getString("ai_endpoint","https://api.openai.com/v1/responses"));
        l.addView(key);l.addView(model);l.addView(endpoint);
        TextView note=tv("نکته امنیتی: کلید روی همین گوشی ذخیره می‌شود. برای استفاده حرفه‌ای و چنددستگاهی بهتر است بعداً یک سرور واسط امن برای کلید بسازیم.",13); note.setTextColor(RED); l.addView(note);
        new AlertDialog.Builder(this).setTitle("تنظیم دستیار AI").setView(l).setPositiveButton("ذخیره",(d,w)->{getPreferences(MODE_PRIVATE).edit().putString("ai_key",key.getText().toString().trim()).putString("ai_model",model.getText().toString().trim()).putString("ai_endpoint",endpoint.getText().toString().trim()).apply();toast("تنظیمات AI ذخیره شد");}).setNegativeButton("لغو",null).show();
    }
    void settings(){base("تنظیمات و پشتیبان");addBtn("🎯 هدف صندوق خرید",v->{EditText e=input("هدف به تومان");e.setText(""+db.get("fund",50000000));new AlertDialog.Builder(this).setTitle("هدف").setView(e).setPositiveButton("ذخیره",(d,w)->db.set("fund",num(e))).setNegativeButton("لغو",null).show();});addBtn("🧾 اشتراک آخرین فاکتور",v->{if(lastInvoice.isEmpty())toast("فاکتوری نداریم");else share(lastInvoice);});addBtn("🖨 چاپ آخرین فاکتور",v->{if(lastInvoice.isEmpty())toast("فاکتوری نداریم");else print(lastInvoice);});addBtn("💾 خروجی پشتیبان",v->backup());addBtn("🔐 قفل برنامه — آماده نسخه بعد",v->toast("قفل با رمز در نسخه بعد فعال می‌شود"));addBtn("📱 پیامک بانکی — نسخه بعد",v->toast("ساختار حسابداری آماده است؛ اتصال SMS در نسخه بعد اضافه می‌شود"));addBtn("↩ بازگشت",v->showHome());}
    void share(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"اشتراک"));}
    void print(final String text){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("فاکتور علیزاده",new PrintDocumentAdapter(){public void onLayout(PrintAttributes a,PrintAttributes b,CancellationSignal c,LayoutResultCallback cb,Bundle x){cb.onLayoutFinished(new PrintDocumentInfo.Builder("invoice.txt").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(),true);}public void onWrite(PageRange[] p,ParcelFileDescriptor fd,CancellationSignal c,WriteResultCallback cb){try{FileOutputStream o=new FileOutputStream(fd.getFileDescriptor());o.write(text.getBytes("UTF-8"));o.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.getMessage());}}},null);}
    void backup(){try{File f=new File(getExternalFilesDir(null),"alizadeh-backup-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".txt");FileWriter w=new FileWriter(f);String[] tabs={"products","sales","sale_lines","purchases","customers","cashbook","checks","expenses","reminders","alloc","movements","settings"};for(String t:tabs){w.write("### "+t+"\n");Cursor c=db.q("SELECT * FROM "+t);while(c.moveToNext()){for(int j=0;j<c.getColumnCount();j++)w.write(c.getColumnName(j)+"="+c.getString(j)+" | ");w.write("\n");}c.close();}w.close();Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_STREAM,android.net.Uri.fromFile(f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"ارسال پشتیبان"));}catch(Exception e){toast("پشتیبان‌گیری: "+e.getMessage());}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    static class Product{int id;String name;double stock,minStock;long cost,sale1,sale2,sale3;Product(int i,String n,double st,long c,long s1,long s2,long s3,double min){id=i;name=n;stock=st;cost=c;sale1=s1;sale2=s2;sale3=s3;minStock=min;}}

    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"jarvis_alizadeh.db",null,2);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,stock REAL NOT NULL DEFAULT 0,cost INTEGER NOT NULL DEFAULT 0,sale1 INTEGER NOT NULL DEFAULT 0,sale2 INTEGER NOT NULL DEFAULT 0,sale3 INTEGER NOT NULL DEFAULT 0,minStock REAL NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT NOT NULL,kind TEXT NOT NULL,productId INTEGER,product TEXT,qty REAL,price INTEGER,discount INTEGER,total INTEGER,profit INTEGER,customer TEXT,paid INTEGER DEFAULT 0)");
            d.execSQL("CREATE TABLE sale_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,saleId INTEGER,productId INTEGER,qty REAL,price INTEGER,cost INTEGER,total INTEGER,profit INTEGER)");
            d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT,productId INTEGER,product TEXT,qty REAL,cost INTEGER,total INTEGER,supplier TEXT,paid INTEGER DEFAULT 0)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,balance INTEGER DEFAULT 0)");
            d.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,balance INTEGER DEFAULT 0)");
            d.execSQL("CREATE TABLE cashbook(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT,title TEXT,amount INTEGER,kind TEXT,account TEXT,note TEXT)");
            d.execSQL("CREATE TABLE checks(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT,party TEXT,amount INTEGER,due TEXT,number TEXT,status TEXT DEFAULT 'باز',kind TEXT DEFAULT 'دریافتی')");
            d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT,title TEXT,amount INTEGER,type TEXT,paid INTEGER DEFAULT 0,due TEXT)");
            d.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,note TEXT,due TEXT,done INTEGER DEFAULT 0)");
            d.execSQL("CREATE TABLE alloc(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT,bucket TEXT,amount INTEGER)");
            d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,dt TEXT,productId INTEGER,product TEXT,kind TEXT,qty REAL,balance REAL,amount INTEGER)");
            d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v INTEGER)");
            set("fund",50000000);set("buy",50);set("inst",30);set("personal",20);
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){if(o<2){try{d.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,balance INTEGER DEFAULT 0)");}catch(Exception ignored){} try{d.execSQL("ALTER TABLE checks ADD COLUMN kind TEXT DEFAULT 'دریافتی'");}catch(Exception ignored){}}}
        Cursor q(String sql){return getReadableDatabase().rawQuery(sql,null);}
        long sum(String t,String col,String where){String sql="SELECT COALESCE(SUM("+col+"),0) FROM "+t+(where==null||where.isEmpty()?"":" WHERE "+where);Cursor c=q(sql);long x=0;if(c.moveToFirst())x=c.getLong(0);c.close();return x;}
        void set(String k,long v){getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
        long get(String k,long def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});long x=def;if(c.moveToFirst())x=c.getLong(0);c.close();return x;}
        void create(String n,long cost,long s1,long s2,long s3,double min){ContentValues v=new ContentValues();v.put("name",n);v.put("cost",cost);v.put("sale1",s1);v.put("sale2",s2);v.put("sale3",s3);v.put("minStock",min);getWritableDatabase().insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
        Product find(String x){Cursor c=getReadableDatabase().rawQuery("SELECT id,name,stock,cost,sale1,sale2,sale3,minStock FROM products WHERE name LIKE ? ORDER BY id DESC LIMIT 1",new String[]{"%"+x+"%"});if(!c.moveToFirst()){c.close();return null;}Product p=new Product(c.getInt(0),c.getString(1),c.getDouble(2),c.getLong(3),c.getLong(4),c.getLong(5),c.getLong(6),c.getDouble(7));c.close();return p;}
        Product getProduct(int id){Cursor c=q("SELECT id,name,stock,cost,sale1,sale2,sale3,minStock FROM products WHERE id="+id);c.moveToFirst();Product p=new Product(c.getInt(0),c.getString(1),c.getDouble(2),c.getLong(3),c.getLong(4),c.getLong(5),c.getLong(6),c.getDouble(7));c.close();return p;}
        void updateProduct(int id,String n,long c,long s1,long s2,long s3,double min){getWritableDatabase().execSQL("UPDATE products SET name=?,cost=?,sale1=?,sale2=?,sale3=?,minStock=? WHERE id=?",new Object[]{n,c,s1,s2,s3,min,id});}
        long postSale(int pid,String name,double q,long price,long discount,long total,long profit,String customer,long paid,String kind){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();long id=-1;try{ContentValues v=new ContentValues();v.put("dt",now());v.put("kind",kind);v.put("productId",pid);v.put("product",name);v.put("qty",q);v.put("price",price);v.put("discount",discount);v.put("total",total);v.put("profit",profit);v.put("customer",customer);v.put("paid",paid);id=d.insertOrThrow("sales",null,v);if("SALE".equals(kind)){d.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{q,pid});Product p=getProduct(pid);movement(d,pid,name,"فروش",-q,p.stock,total);if(customer!=null&&!customer.trim().isEmpty()){d.execSQL("INSERT OR IGNORE INTO customers(name,balance) VALUES(?,0)",new Object[]{customer});d.execSQL("UPDATE customers SET balance=balance+? WHERE name=?",new Object[]{total-paid,customer});}if(paid>0){cash(d,"فروش #"+id,paid,"IN","نقدی","دریافت فروش");}allocate(d,total-paid);}ContentValues l=new ContentValues();l.put("saleId",id);l.put("productId",pid);l.put("qty",q);l.put("price",price);l.put("cost",getProduct(pid).cost);l.put("total",total);l.put("profit",profit);d.insertOrThrow("sale_lines",null,l);d.setTransactionSuccessful();}finally{d.endTransaction();}return id;}
        void postPurchase(int pid,String name,double q,long cost,String sup,long paid){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{Product oldP=getProduct(pid); double oldStock=oldP.stock; long oldCost=oldP.cost; double newStock=oldStock+q; long avgCost=newStock<=0?cost:Math.round(((oldStock*oldCost)+(q*cost))/newStock); d.execSQL("UPDATE products SET stock=stock+?,cost=? WHERE id=?",new Object[]{q,avgCost,pid});Product p=getProduct(pid);long purchaseTotal=Math.round(q*cost);d.execSQL("INSERT INTO purchases(dt,productId,product,qty,cost,total,supplier,paid) VALUES(?,?,?,?,?,?,?,?)",new Object[]{now(),pid,name,q,cost,purchaseTotal,sup,paid});if(sup!=null&&!sup.trim().isEmpty()){d.execSQL("INSERT OR IGNORE INTO suppliers(name,balance) VALUES(?,0)",new Object[]{sup});d.execSQL("UPDATE suppliers SET balance=balance+? WHERE name=?",new Object[]{purchaseTotal-paid,sup});}movement(d,pid,name,"خرید",q,p.stock,purchaseTotal);if(paid>0)cash(d,"خرید "+name,paid,"OUT","نقدی","پرداخت خرید");d.setTransactionSuccessful();}finally{d.endTransaction();}}
        void movement(SQLiteDatabase d,int pid,String name,String kind,double q,double bal,long amount){d.execSQL("INSERT INTO movements(dt,productId,product,kind,qty,balance,amount) VALUES(?,?,?,?,?,?,?)",new Object[]{now(),pid,name,kind,q,bal,amount});}
        void allocate(SQLiteDatabase d,long amount){if(amount<=0)return;long a=amount*get("buy",50)/100,b=amount*get("inst",30)/100,c=amount-a-b;d.execSQL("INSERT INTO alloc(dt,bucket,amount) VALUES(?,?,?)",new Object[]{now(),"خرید",a});d.execSQL("INSERT INTO alloc(dt,bucket,amount) VALUES(?,?,?)",new Object[]{now(),"قسط/هزینه",b});d.execSQL("INSERT INTO alloc(dt,bucket,amount) VALUES(?,?,?)",new Object[]{now(),"شخصی",c});}
        void payment(String name,long amount,String type){SQLiteDatabase d=getWritableDatabase();if(name.trim().isEmpty())return;if("customer".equals(type)){d.execSQL("INSERT OR IGNORE INTO customers(name,balance) VALUES(?,0)",new Object[]{name});d.execSQL("UPDATE customers SET balance=MAX(0,balance-?) WHERE name=?",new Object[]{Math.abs(amount),name});cash(d,"دریافت از "+name,Math.abs(amount),"IN","نقدی","تسویه حساب");}else{d.execSQL("INSERT OR IGNORE INTO suppliers(name,balance) VALUES(?,0)",new Object[]{name});d.execSQL("UPDATE suppliers SET balance=MAX(0,balance-?) WHERE name=?",new Object[]{Math.abs(amount),name});cash(d,"پرداخت به "+name,Math.abs(amount),"OUT","نقدی","تسویه تامین‌کننده");}}
        void cash(SQLiteDatabase d,String title,long amount,String kind,String account,String note){d.execSQL("INSERT INTO cashbook(dt,title,amount,kind,account,note) VALUES(?,?,?,?,?,?)",new Object[]{now(),title,amount,kind,account,note});}
        void cash(String title,long amount,String kind,String account,String note){cash(getWritableDatabase(),title,amount,kind,account,note);}
        void check(String party,long amount,String due,String no,String kind){getWritableDatabase().execSQL("INSERT INTO checks(dt,party,amount,due,number,status,kind) VALUES(?,?,?,?,?,'باز',?)",new Object[]{now(),party,amount,due,no,kind});}
        long expense(String title,long amount,String type,String due,boolean paid){ContentValues v=new ContentValues();v.put("dt",now());v.put("title",title);v.put("amount",amount);v.put("type",type);v.put("due",due);v.put("paid",paid?1:0);long id=getWritableDatabase().insert("expenses",null,v);if(paid)cash("هزینه: "+title,amount,"OUT","نقدی","هزینه");return id;}
        long reminder(String title,String note,String due){ContentValues v=new ContentValues();v.put("title",title);v.put("note",note);v.put("due",due);return getWritableDatabase().insert("reminders",null,v);}
        void doneReminder(long id){getWritableDatabase().execSQL("UPDATE reminders SET done=1 WHERE id=?",new Object[]{id});}
        void returnSale(long id,double q){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{Cursor c=d.rawQuery("SELECT productId,product,qty,total,paid,customer FROM sales WHERE id=? AND kind='SALE'",new String[]{""+id});if(!c.moveToFirst()){c.close();throw new IllegalArgumentException("فاکتور فروش پیدا نشد");}int pid=c.getInt(0);String name=c.getString(1);double oldq=c.getDouble(2);long total=c.getLong(3),paid=c.getLong(4);String cust=c.getString(5);c.close();Cursor l=d.rawQuery("SELECT qty,total,profit FROM sale_lines WHERE saleId=? LIMIT 1",new String[]{""+id});if(!l.moveToFirst()){l.close();throw new IllegalArgumentException("جزئیات فاکتور پیدا نشد");}double lineQty=l.getDouble(0);long lineTotal=l.getLong(1),lineProfit=l.getLong(2);l.close();if(q<=0||q>oldq||q>lineQty)throw new IllegalArgumentException("تعداد مرجوعی نامعتبر");long refund=Math.round(total*(q/oldq));long refundPaid=Math.round(paid*(q/oldq));long refundProfit=Math.round(lineProfit*(q/lineQty));d.execSQL("UPDATE products SET stock=stock+? WHERE id=?",new Object[]{q,pid});Product p=getProduct(pid);movement(d,pid,name,"مرجوعی",q,p.stock,-refund);d.execSQL("UPDATE sales SET qty=qty-?,total=total-?,paid=MAX(0,paid-?),profit=profit-?,discount=MAX(0,discount-?) WHERE id=?",new Object[]{q,refund,refundPaid,refundProfit,Math.round((total==0?0:0)),id});d.execSQL("UPDATE sale_lines SET qty=qty-?,total=total-?,profit=profit-? WHERE saleId=?",new Object[]{q,Math.round(lineTotal*(q/lineQty)),refundProfit,id});if(cust!=null&&!cust.trim().isEmpty())d.execSQL("UPDATE customers SET balance=MAX(0,balance-?) WHERE name=?",new Object[]{refund-refundPaid,cust});if(refundPaid>0)cash(d,"مرجوعی فاکتور #"+id,refundPaid,"OUT","نقدی","بازگشت وجه");d.setTransactionSuccessful();}finally{d.endTransaction();}}
        long inventoryValue(){Cursor c=q("SELECT COALESCE(SUM(stock*cost),0) FROM products");long x=c.moveToFirst()?c.getLong(0):0;c.close();return x;}
        long todaySales(){return sum("sales","total","kind='SALE' AND dt LIKE '"+today()+"%'");}
        long todayProfit(){return sum("sales","profit","kind='SALE' AND dt LIKE '"+today()+"%'");}
        long lowStockCount(){Cursor c=q("SELECT COUNT(*) FROM products WHERE stock<=minStock");long x=c.moveToFirst()?c.getLong(0):0;c.close();return x;}
    }
}
